export const contactsData = {
    email: 'contact@ndiagandiaye.com',
    phone: '+221 78 163 34 19',
    address: 'Scat Urbam, Dakar, Sénégal - 11500',
    sheetAPI: 'https://www.ndiagandiaye.com/send-email',
};