export const aboutData = {
    title: "Qui suis-je ?",
    description1: "Mon nom est Ndiaga Ndiaye, je suis développeur JavaScript FullStack et designer UI/UX en freelance.",
    description2: "J'accompagne les entreprises dans leur transformation digitale, en travaillant sur la création de sites web professionnels, de logiciels métiers, et en offrant des services en UI/UX design et marketing digital. Pendant mon temps libre, je crée des produits et explore l'apprentissage automatique et l'IA. J'aime apprendre et explorer de nouvelles sphères.",
    image: 1
}