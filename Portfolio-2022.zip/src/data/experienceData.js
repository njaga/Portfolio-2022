export const experienceData = [
    {
        id: 1,
        company: 'Vigilus Group SA',
        jobtitle: 'Chef de projet digital',
        startYear: '2022',
        endYear: '2024'
    },
    {
        id: 3,
        company: 'Carré d\'Or',
        jobtitle: 'Digital manager',
        startYear: '2023',
        endYear: '2024'
    },
    {
        id: 2,
        company: 'L\'Influent',
        jobtitle: 'Front-end Developer',
        startYear: '2020',
        endYear: '2021'
    },
]