export const socialsData = {
    github: 'https://github.com/njaga',
    facebook: 'https://www.facebook.com/njaganjaay',
    linkedIn: 'https://www.linkedin.com/in/ndiagandiaye',
    instagram: 'https://www.instagram.com/ndiagandiaye01/',
    codepen: 'https://codepen.io/',
    twitter: 'https://x.com/ndiaga_dev',
    reddit: 'https://www.reddit.com/user/',
    blogger: 'https://www.blogger.com/',
    medium: 'https://medium.com/@',
    stackOverflow: 'https://stackoverflow.com/users/',
    gitlab: 'https://gitlab.com/',
    youtube: 'https://youtube.com/'
}